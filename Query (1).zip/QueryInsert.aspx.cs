﻿using System;
using System.Web.UI;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Data;

public partial class QueryInsert : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ShowData();
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {

        try
        {
            if (Page.IsValid)
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("Insert into Reports_SK(SQL_DESC,SQL_Q,User_Name) values (@SQL_DESC,@SQL_Q,@User_Name) ", con);
                cmd.Parameters.AddWithValue("@SQL_DESC", txtQuery.Text);
                cmd.Parameters.AddWithValue("@SQL_Q", txtQueryDesc.Text);
                cmd.Parameters.AddWithValue("@User_Name", ddlUserName.SelectedValue);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Dispose();
                Response.Write("Data Saved Successfully");

                ShowData();
            }
        }
        catch (Exception ex)
        {
            Response.Write("Unable to Save" + ex.Message);
        }
    }

    protected void ShowData()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString);
        con.Open();

        DataTable dt = new DataTable();

        SqlDataAdapter adapt = new SqlDataAdapter("Select ID,SQL_DESC,SQL_Q from Reports_SK where User_Name = '" + ddlUserName.SelectedValue + "' ", con);
        adapt.Fill(dt);

        GridView1.DataBind();
        if (dt.Rows.Count > 0)
        {
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        con.Close();
    }

    protected void GridView1_RowEditing(object sender, System.Web.UI.WebControls.GridViewEditEventArgs e)
    {
        //NewEditIndex property used to determine the index of the row being edited.
        GridView1.EditIndex = e.NewEditIndex;
        ShowData();
    }
    protected void GridView1_RowUpdating(object sender, System.Web.UI.WebControls.GridViewUpdateEventArgs e)
    {
        //Finding the controls from Gridview for the row which is going to update
        Label id = GridView1.Rows[e.RowIndex].FindControl("lbl_ID") as Label;
        TextBox txt_Desc = GridView1.Rows[e.RowIndex].FindControl("txt_Desc") as TextBox;
        TextBox txt_Q = GridView1.Rows[e.RowIndex].FindControl("txt_Q") as TextBox;

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString);
        con.Open();
        //updating the record
        SqlCommand cmd = new SqlCommand("Update Reports_SK set SQL_DESC='" + txt_Desc.Text + "',SQL_Q='" + txt_Q.Text + "' where ID='" + id.Text + "'", con);
        cmd.ExecuteNonQuery();
        con.Close();
        //Setting the EditIndex property to -1 to cancel the Edit mode in Gridview
        GridView1.EditIndex = -1;
        //Call ShowData method for displaying updated data
        ShowData();
    }
    protected void GridView1_RowCancelingEdit(object sender, System.Web.UI.WebControls.GridViewCancelEditEventArgs e)
    {
        //Setting the EditIndex property to -1 to cancel the Edit mode in Gridview
        GridView1.EditIndex = -1;
        ShowData();
    }

    protected void ddlUserName_SelectedIndexChanged(object sender, EventArgs e)
    {
        ShowData();
    }

    protected void ddlUserName_TextChanged(object sender, EventArgs e)
    {
        ShowData();
    }

   
}