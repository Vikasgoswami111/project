﻿using System;
using System.Web.UI;
using System.Configuration;
using System.Data.SqlClient;

public partial class QueryInsert : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnSave_Click(object sender, EventArgs e)
    {

        try
        {
            if (Page.IsValid)
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("Insert into Query_Table(QueryText) values (@QueryText) ", con);
                cmd.Parameters.AddWithValue("@QueryText", txtQuery.Text);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Dispose();
                Response.Write("Data Saved Successfully");
            }
        }
        catch (Exception ex)
        {
            Response.Write("Unable to Save" + ex.Message);
        }
    }
}