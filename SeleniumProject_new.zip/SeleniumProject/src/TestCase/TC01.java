package TestCase;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TC01 {
	String Browser = "Chrome";
	WebDriver driver = null;

	@BeforeClass
	public void setUp() {
		if (Browser.equals("Chrome")) {
			String exePath = System.getProperty("user.dir") + "\\Driver\\chromedriver.exe";
			System.setProperty("webdriver.chrome.driver", exePath);
			driver = new ChromeDriver();
		} else if (Browser.equals("Firefox")) {
			String exePath = System.getProperty("user.dir") + "\\Driver\\geckodriver.exe";
			System.setProperty("webdriver.gecko.driver", exePath);
			driver = new FirefoxDriver();
		} else if (Browser.equals("IE")) {
			String exePath = System.getProperty("user.dir") + "\\Driver\\IEDriverServer.exe";
			System.setProperty("webdriver.ie.driver", exePath);
			driver = new InternetExplorerDriver();
		}
		driver.manage().window().maximize();
		driver.get("https://demo.bigtreecms.org/admin/login/");
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	}

	@BeforeMethod
	public void Login() {
		driver.findElement(By.id("user")).sendKeys("demo@bigtreecms.org");
		driver.findElement(By.id("password")).sendKeys("demo");
		driver.findElement(By.xpath("//input[@type='submit']")).submit();

	}

	@Test(enabled = true)
	public void TC_01() throws InterruptedException {

		driver.findElement(By.linkText("Files")).click();
		driver.findElement(By.linkText("Add Video")).click();

		driver.findElement(By.id("file_manager_field_video")).sendKeys("https://www.youtube.com/watch?v=hnEQq7kNFWo");

		driver.findElement(By.xpath("//input[@type='submit' and @value ='Continue']")).submit();

		String count_current = driver.findElement(By.xpath("//span[@class='count current']")).getText();
		String count_total = driver.findElement(By.xpath("//span[@class='count total']")).getText();

		int currentCount = Integer.valueOf(count_current);
		int TotalCount = Integer.valueOf(count_total);

		for (int i = currentCount; i <= TotalCount; i++) {

			System.out.println("i =" + i);
			System.out.println(String.valueOf(i));
			System.out.println(
					driver.findElement(By.xpath("//h2[@class='cropper']/span[@class='count current']")).getText());
			if (String.valueOf(i).equals(
					driver.findElement(By.xpath("//h2[@class='cropper']/span[@class='count current']")).getText())) {
				driver.findElement(By.xpath("//input[@type='submit' and @value ='Crop Image' ]")).submit();
			}

		}

		driver.findElement(By.xpath("//input[@type='submit' and @value ='Update File']")).submit();

	}

	@Test(enabled = true)
	public void TC_02() throws InterruptedException {

		driver.findElement(By.linkText("Files")).click();
		driver.findElement(By.linkText("Add Files")).click();

		driver.findElement(By.id("file_manager_dropzone")).click();
		uploadFileWithRobot(System.getProperty("user.dir") + "\\Upload\\Test File.txt");

		driver.findElement(By.xpath("//a[text()='Continue' and @class ='blue button js-continue-button']")).click();

		driver.findElement(By.xpath("//input[@type='submit' and @value ='Update File']")).submit();

	}

	@Test
	public void TC_03() throws InterruptedException {

		driver.findElement(By.linkText("Files")).click();
		driver.findElement(By.linkText("Add Images")).click();

		driver.findElement(By.id("file_manager_dropzone")).click();
		uploadFileWithRobot(System.getProperty("user.dir") + "\\Upload\\test.jpeg");

		driver.findElement(By.xpath("//input[@type='submit' and @value ='Continue' and @class ='blue button js-continue-button']")).click();

		String count_current = driver.findElement(By.xpath("//span[@class='count current']")).getText();
		String count_total = driver.findElement(By.xpath("//span[@class='count total']")).getText();

		int currentCount = Integer.valueOf(count_current);
		int TotalCount = Integer.valueOf(count_total);

		for (int i = currentCount; i <= TotalCount; i++) {

			System.out.println("i =" + i);
			System.out.println(String.valueOf(i));
			System.out.println(
					driver.findElement(By.xpath("//h2[@class='cropper']/span[@class='count current']")).getText());
			if (String.valueOf(i).equals(
					driver.findElement(By.xpath("//h2[@class='cropper']/span[@class='count current']")).getText())) {
				driver.findElement(By.xpath("//input[@type='submit' and @value ='Crop Image' ]")).submit();
			}

		}

		driver.findElement(By.xpath("//input[@type='submit' and @value ='Update File']")).submit();

	}

	@AfterMethod
	public void Logout() {
		driver.findElement(By.linkText("Logout")).click();
	}

	@AfterClass
	public void tearDown() {
		//driver.quit();
	}

	public void uploadFileWithRobot(String imagePath) {
		StringSelection stringSelection = new StringSelection(imagePath);
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(stringSelection, null);

		Robot robot = null;

		try {
			robot = new Robot();
		} catch (AWTException e) {
			e.printStackTrace();
		}
		try {
			robot.delay(250);
			robot.keyRelease(KeyEvent.VK_ENTER);
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			Thread.sleep(2000);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.delay(150);
			robot.keyRelease(KeyEvent.VK_ENTER);

			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
